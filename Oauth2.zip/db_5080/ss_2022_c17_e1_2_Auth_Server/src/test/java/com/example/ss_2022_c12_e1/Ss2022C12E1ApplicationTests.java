package com.example.ss_2022_c12_e1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ss2022C12E1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
