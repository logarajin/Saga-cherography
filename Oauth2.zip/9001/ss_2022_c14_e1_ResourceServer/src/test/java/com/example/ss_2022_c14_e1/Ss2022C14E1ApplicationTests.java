package com.example.ss_2022_c14_e1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ss2022C14E1ApplicationTests {

  @Test
  void contextLoads() {
  }

}
