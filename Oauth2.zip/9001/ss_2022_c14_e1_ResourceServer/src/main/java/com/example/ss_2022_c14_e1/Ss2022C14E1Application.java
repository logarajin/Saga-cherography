package com.example.ss_2022_c14_e1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ss2022C14E1Application {

  public static void main(String[] args) {
    SpringApplication.run(Ss2022C14E1Application.class, args);
  }

}
